package com.example.cmaisonneuve;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.Group;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class IMCActivity extends AppCompatActivity {

    // declarer tous les elements que vous voulez referencer
    private EditText poidsText;
    private EditText tailleText;
    private TextView resultatText;
    private Button buttonCalculer;
    private Button buttonEffacer;
    private RadioGroup mesureGroup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);
        poidsText = findViewById(R.id.poids_id);
        tailleText = findViewById(R.id.taille_id);
        resultatText = findViewById(R.id.resultat);
        buttonCalculer = findViewById(R.id.btn_calculer);
        buttonEffacer = findViewById(R.id.btn_effacer);
        mesureGroup = findViewById(R.id.mesure_id);


        //-- recupere la valeur du username
        Intent intent = getIntent();
        String usernameIntentValue = intent.getStringExtra("USERNAME_VALUE");
        Toast.makeText(getApplicationContext(), "Bienvenue " + usernameIntentValue,Toast.LENGTH_LONG).show();
        buttonCalculer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               calculIMC();
         }
        });



        buttonEffacer.setOnClickListener(effacerTextListener);

    }

    private View.OnClickListener effacerTextListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            poidsText.setText("");
            tailleText.getText().clear();
            resultatText.setText("Resultat :");
        }
    };




    private void calculIMC() {
        // on recupere le poids
        String poids =poidsText.getText().toString();
        // on recupere la taille
        String taille = tailleText.getText().toString();
        float poidsF = Float.valueOf(poids);
        float tailleF = Float.valueOf(taille);

        if(tailleF == 0)
            Toast.makeText(getApplicationContext(), "La taille ne peut pas etre egale a zero",Toast.LENGTH_SHORT).show();
        else {
            // -- verifier si l utilisateur choisi centimetre
            if(mesureGroup.getCheckedRadioButtonId()==R.id.centimetre_id)
                tailleF = tailleF / 100;
            tailleF = (float) Math.pow(tailleF, 2);
            float imc = poidsF / tailleF;
            resultatText.setText("Votre IMC est: " + imc);
        }

    }
}